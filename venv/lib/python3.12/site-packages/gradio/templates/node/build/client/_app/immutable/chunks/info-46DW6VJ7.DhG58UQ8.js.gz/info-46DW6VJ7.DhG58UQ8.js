import { I, c } from "./mermaid-parser.core.BDi_Rp4T.js";
export {
  I as InfoModule,
  c as createInfoServices
};
