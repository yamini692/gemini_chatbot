import { a2, a1 } from "../chunks/2.DU5PbPFs.js";
export {
  a2 as component,
  a1 as universal
};
