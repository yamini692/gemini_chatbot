import { G, f } from "./mermaid-parser.core.BDi_Rp4T.js";
export {
  G as GitGraphModule,
  f as createGitGraphServices
};
