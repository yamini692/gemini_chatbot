import { P, a } from "./mermaid-parser.core.BDi_Rp4T.js";
export {
  P as PacketModule,
  a as createPacketServices
};
