import { A, e } from "./mermaid-parser.core.BDi_Rp4T.js";
export {
  A as ArchitectureModule,
  e as createArchitectureServices
};
